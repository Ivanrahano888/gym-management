<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    
</head>
<body>
    <div class="container p-5 m-5">
        <h1 class="fw-bold">💪 Gym-management</h1>
        <p>A gym management web application.</p>
        <a href="<?php echo e(route('create')); ?>" class="btn btn-info btn-sm">+ Create an account</a>
        <?php if(session('success')): ?>
            <div class="alert alert-success my-3" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table mt-3">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Membership_type</th>
                <th>Membership_expiration</th>
                <th>Actions</th>
            </tr>
            <?php if(count($member)>0): ?>
                <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($member->id); ?></td>
                    <td><?php echo e($member->name); ?></td>
                    <td><?php echo e($member->email); ?></td>
                    <td><?php echo e($member->membership_type); ?></td>
                    <td><?php echo e($member->membership_expiration); ?></td>
                    <td>
                        <a class="btn btn-sm btn-secondary" href="<?php echo e(route('show', $member->id)); ?>">👁️</a>
                        <a class="btn btn-sm btn-secondary" href="<?php echo e(route('edit', $member->id)); ?>">✍️</a>
                        <a class="btn btn-sm btn-secondary" href="<?php echo e(route('destroy', $member->id)); ?>">♻</a>
                    </td>
                </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            </tr>
                <td colspan="6" class="text-center p-5 m-5">
                Members are hidden.
                </td>
            </tr>
            <?php endif; ?>

        </table>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\gym-management\resources\views/index.blade.php ENDPATH**/ ?>