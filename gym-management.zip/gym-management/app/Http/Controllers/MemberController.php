<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Member;

class MemberController extends Controller
{

    public function index() 
    {
        return view('index')->with('member', Member::all());
    }
    public function create() 
    {
        return view('create');
    }
    public function store(Request $request)
    {
        $member = new Member;

        $member->name                     = $request->name;
        $member->email                    = $request->email;
        $member->membership_type          = $request->membership_type;
        $member->membership_expiration    = $request->membership_expiration;

        $member->save();
    
        return redirect()->route('index')->with('success', 'New member added successfully!');
    
    }
    public function show($id)
    {
        $member = Member::find($id);
        
        return view('show')->with('member', $member);
    }

    public function edit($id)
{
    $member = Member::find($id);
    
    return view('edit')->with('member', $member);
}
    public function update(Request $request)
{
   
    $member->name                     = $request->name;
    $member->email                    = $request->email;
    $member->membership_type          = $request->membership_type;
    $member->membership_expiration    = $request->membership_expiration;

    $member->save();

    return redirect()->route('index')->with('success', 'Members information updated successfully!');
    }
    public function destroy($id)
{
    $member = Member::find($id);
    $member->delete();

    return redirect()->route('index')->with('success', 'A member deleted successfully!');
}
}